//
//  ViewController.h
//  ALiEditPhotoCollection
//
//  Created by LeeWong on 2016/9/28.
//  Copyright © 2016年 LeeWong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

